#include "myStrings.h"

// Rewrite this so that only pointers are used, no array concepts.

/**
 * copy characters of src to dst (including '\0')
 * We assume tht the caller has sufficient space!
 */
void myStrCpy(char *dst, char *src){
	char *cpSrc, *cpDst;
	cpSrc = src;
	cpDst = dst;
	while(*cpSrc!='\0'){
		*cpDst=*cpSrc;
		cpSrc++;
		cpDst++;
	}
	*cpDst=*cpSrc;
}

/**
 * returns the length of string s
 * this is the number of non-null characters in s
 */
int myStrLen(char *s){
	int len = 0;
	char *cp;
	cp = s;
	while(*cp!='\0'){
		cp++;
		len = len + 1;
	}
	return(len);
}

/**
 * returns whether s is the empty string
 */
int myisStrEmpty(char *s){
	return *s=='\0';
}

/**
 * returns whether s1 is equal to s2
 */
int myisStrEQ(char *s1, char *s2){
	char *cpS1, *cpS2;
	cpS1 = s1;
	cpS2 = s2;
	while(*cpS1==*cpS2 && *cpS1!='\0' && *cpS2!='\0'){
		cpS1++;
		cpS2++;
	}
	if(*cpS1=='\0' && *cpS2=='\0')return 1;
	else return 0;
}


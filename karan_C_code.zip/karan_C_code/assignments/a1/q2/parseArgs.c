#include <stdio.h>
#include "myStrings.h"
#include "parseArgs.h"

int iWord=-1, iFileName=-1;

/**
 * print the usage message
 */
void usage(){

	//printf("This function looks at argc and argv, does not open files etc. It just determines if the command line arguments make sense for hasWord. It returns \n 0 for failure\n 1 for success\n 2 for having printed the usage message (--help).\n --help in any parameter means print usage message\n It appropriately sets \n iWord=the index in argv of the word to search for iFileName=the index in argv of the filename, -1 means no filename supplied\n If iFileName ==-1, the caller knows that no filename is supplied  and hasWord should read from stdin.");
	printf("Usage: ./hasWord [word] [FILE]\n");
   printf("With no FILE, or when FILE is -, read standard input.\n");
   printf("Examples: \n");
   printf("\t$ hasWord word # reads stdin \n");
   printf("\t$ hasWord word filename # reads filename\n");
   printf("\t$ hasWord with incorrect arguments, sends an error message to stderr, sets returncode to 127\n");
   printf("\t$ hasWord --help # prints out a usage message, sets returncode to 0\n");
}

/**
 * print error message to stderr
 */
void optionsError(char mesg[]){
	fprintf(stderr, "hasWord: %s\nTry 'hasWord --help' for more information.\n", mesg);
}

/**
 * parse and understand the args. 
 * returns 1 for success, 0 for error, 2 for --help printed
 * On success, iWord, iFileName are all properly initialized
 * iFileName == -1 indicates read from stdin
 */
int parseArgs(int argc, char *argv[]){
    if (argc == 0 || argc == 1) {
      optionsError("incorrect number of arguments");
      iWord=-1, iFileName=-1;
      return 0;
  }
   
   for (int j = 1; j < argc; j++) {
      if(myisStrEQ(argv[j], "--help") == 1){
         usage();
         iWord=-1, iFileName=-1;
         return 2;
      }
   }
   //Now I dont need to worry about help
   if (argc > 3) {
      optionsError("incorrect number of arguments");
      iWord=-1, iFileName=-1;
      return 0;
  }

  // Now there are the right number of arguments

  iWord = 1;

  if (2 < argc){
   iFileName = 2;
  }
  return 1;
}

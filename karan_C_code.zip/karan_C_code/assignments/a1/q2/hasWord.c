#include <stdio.h>
#include <stdlib.h>
#include "myStrings.h"
#include "parseArgs.h"

/**
 * return whether word appears in open fpin
 */
int isWordInFile(char word[], int wordLen, FILE *fpin){
	int i, c;
	char check[wordLen+ 1];
	check[wordLen] = '\0';
	//compare word with check;
	for (int i = 0; i < wordLen; i++) {
    	 c = fgetc(fpin);
		if (c != EOF){
			check[i] = c;
			//check gets populated
		}
		else{
			return 1;
			//insufficent chars
		}
    
	}
	while((c = fgetc(fpin)) != EOF){
		//checking if the check and word are equal
		if(myisStrEQ(check, word) == 1){
			return 0;
		}
		for (int i = 0; i < wordLen - 1; i++) {
			check[i] = check[i + 1];
			//shift everything back
		}
		check[wordLen - 1] = c;
		//append new char
		}
	//last check
	if(myisStrEQ(check, word) == 1){
			return 0;
	}
	
	return 1;
	//word not found after iterating through everything
}


int main(int argc, char *argv[]) {
	FILE *fpin;
	//get a flag
	int retVal=parseArgs(argc, argv);
	if (retVal == 2){
		//asked help
		exit(0);
	}
	if (retVal == 1){
		//Valid input
		char *word;
		word = argv[iWord];
		if(iFileName != -1){
			fpin = fopen(argv[iFileName], "r");
			 if (fpin == NULL) {
        		perror("Unable to open file\n");
        		exit(127);
			 }
			 
		}
		else{
			fpin = stdin;
		}
		int k;
		k = isWordInFile(word,myStrLen(word), fpin);
		//printf("The value of number is: %d\n", k);
		//return k;
		fclose(fpin);
		exit(k);
		
	}
	else{
		perror("Incorrect values\n");
		exit(127);

	} 

}

/* server process */

/* include the necessary header files */
#include<ctype.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/select.h>

#include "protocol.h"
#include "libParseMessage.h"
#include "libMessageQueue.h"

typedef struct{
	char username[MAX_USER_LEN+1]; 
	MessageQueue queue;
	int sockfd;
}clientInfo;

int MAX_USERS = 33;


int fixedString(char* src, char* dest) {
    int i = 0;
    while (src[i] != '\0') {
        if (src[i] == '\n') {
            dest[i] = src[i];
            return i;
        } else {
            dest[i] = src[i];
        }
        i++;
    }
    dest[i] = '\n';
	return i;
}

/**
 * send a single message to client 
 * sockfd: the socket to read from
 * toClient: a buffer containing a null terminated string with length at most 
 * 	     MAX_MESSAGE_LEN-1 characters. We send the message with \n replacing \0
 * 	     for a mximmum message sent of length MAX_MESSAGE_LEN (including \n).
 * return 1, if we have successfully sent the message
 * return 2, if we could not write the message
 */
int sendMessage(int sfd, char *toClient){
	char *newToClient = (char*) malloc(sizeof(char) * strlen(toClient) + 1);
	int totalLen = 0;
	totalLen = fixedString(toClient, newToClient) + 1;
	if(totalLen - 1 > MAX_MESSAGE_LEN){
		free(newToClient);
		return(1);
	}
	int offset = 0;
	while (offset < totalLen){

		int numSend = send(sfd, newToClient + offset, totalLen - offset, 0);
		if(numSend == -1){
			free(newToClient);
			return(2);
		}
		offset+= numSend;
	}
	free(newToClient);
	return(1);
}

/**
 * read a single message from the client. 
 * sockfd: the socket to read from
 * fromClient: a buffer of MAX_MESSAGE_LEN characters to place the resulting message
 *             the message is converted from newline to null terminated, 
 *             that is the trailing \n is replaced with \0
 * return 1, if we have received a newline terminated string
 * return 2, if the socket closed (read returned 0 characters)
 * return 3, if we have read more bytes than allowed for a message by the protocol
 */
int recvMessage(int sfd, char *fromClient) {
    char buff[MAX_MESSAGE_LEN];
    int totalBytesRead = 0;
    while (totalBytesRead < MAX_MESSAGE_LEN) {
        int numRecv = recv(sfd, buff + totalBytesRead, MAX_MESSAGE_LEN - totalBytesRead, 0);
        if (numRecv == 0) {
            return 2;
        }
        totalBytesRead += numRecv;
        if (totalBytesRead == strlen(buff) || buff[totalBytesRead - 1] == '\n') {
            break;
        }
    }
    if (totalBytesRead >= MAX_MESSAGE_LEN) {
        return 3;
    }

    int i;
    for (i = 0; i < strlen(buff); i++) {
        fromClient[i] = buff[i] == '\n' ? '\0' : buff[i];
    }
    fromClient[i] = '\0';
	

    return 1;
}

int main (int argc, char ** argv) {
	int len = 0;
	clientInfo allClients[MAX_USERS];
	for(int i = 0; i < MAX_USERS; i++){
	allClients[i].username[0] = '\0';
	allClients[i].sockfd = -1;
	}

   int sockfd;

    if(argc!=2){
	    fprintf(stderr, "Usage: %s portNumber\n", argv[0]);
	    exit(1);
    }
    int port = atoi(argv[1]);

    if ((sockfd = socket (AF_INET, SOCK_STREAM, 0)) == -1) {
        perror ("socket call failed");
        exit (1);
    }

    struct sockaddr_in server;
    server.sin_family=AF_INET;          // IPv4 address
    server.sin_addr.s_addr=INADDR_ANY;  // Allow use of any interface 
    server.sin_port = htons(port);      // specify port

    if (bind (sockfd, (struct sockaddr *) &server, sizeof(server)) == -1) {
        perror ("bind call failed");
        exit (1);
    }

    if (listen (sockfd, 5) == -1) {
        perror ("listen call failed");
        exit (1);
    }
	
	
	allClients[len++].sockfd = sockfd;
	
    for (;;) {

	fd_set readfds, writefds, exceptfds;
	FD_ZERO(&readfds);                    
	FD_ZERO(&writefds);                   
	FD_ZERO(&exceptfds);                 

	int fdmax=0;                          
	for (int i=0; i<len; i++) {
		if (allClients[i].sockfd>0) {
			FD_SET(allClients[i].sockfd, &readfds); 
			fdmax = fdmax>allClients[i].sockfd ? fdmax:allClients[i].sockfd;
		}
	}

	struct timeval tv;  
	tv.tv_sec=5;          
	tv.tv_usec=0;

	int numfds;

	if ((numfds=select(fdmax+1, &readfds, &writefds, &exceptfds, &tv))>0) {

		for (int i=0; i<len; i++) {
			if (FD_ISSET(allClients[i].sockfd, &readfds)) {
				if (allClients[i].sockfd==sockfd) {
					int newsockfd;
					if ((newsockfd = accept (sockfd, NULL, NULL)) == -1) {
						perror ("accept call failed");
						continue;
					}
					if(len<33){ 
						
						initQueue(&(allClients[len].queue));
						allClients[len].sockfd = newsockfd;
						len +=1;
					}
					else{
						close(newsockfd);
					}
				} 
				else { 
					char fromClient[MAX_MESSAGE_LEN], toClient[MAX_MESSAGE_LEN];
					int j;
					for(j = 0; j<MAX_USER_LEN; j++){
						if(allClients[j].sockfd == allClients[i].sockfd ){
							break;
						} 
					}
					int retVal=recvMessage(allClients[i].sockfd, fromClient);
					if(retVal==1){
						char *part[4];
						int numParts=parseMessage(fromClient, part);
						if(numParts==0){
							strcpy(toClient,"ERROR");
							sendMessage(allClients[i].sockfd, toClient);
						}
						
						else if (strncmp(fromClient, "list", 4) == 0) {
							char *msg = malloc(MAX_MESSAGE_LEN + 1);
							if (msg == NULL) {
								perror("malloc failed");
							}
							strcpy(msg, "users:");
							for(int i = 1; i < 11; i++) {
								if(allClients[i].username[0] != '\0'){
									strcat(msg, allClients[i].username);
								}
								if ( i < 10) {
									strcat(msg, " ");
								}
							}
							sendMessage(allClients[i].sockfd, msg);
							free(msg);
						}
						
						else if(strcmp(part[0], "message")==0){
							char *fromUser=part[1];
							char *toUser=part[2];
							char *message=part[3];

							int touserindex2;
							int validFromUser=0, validToUser=0;
							
							if(strcmp(allClients[i].username, fromUser)==0){
								validFromUser = 1;
							}
							for(int j =1; j<len; j++){
								if(strcmp(allClients[j].username, toUser)==0){
									touserindex2 = j;
									validToUser = 1;
								}
							}
							if(validFromUser ==1 && validToUser ==1){
								sprintf(toClient, "%s:%s:%s:%s","message", fromUser, toUser, message);
								if(enqueue(&allClients[touserindex2].queue, toClient)){
									strcpy(toClient, "messageQueued");
									sendMessage(allClients[i].sockfd, toClient);
								}else{
									strcpy(toClient, "messageNotQueued");
									sendMessage(allClients[i].sockfd, toClient);
								}
							}
							if(validFromUser==0){
								sprintf(toClient, "invalidFromUser:%s",fromUser);
								sendMessage(allClients[i].sockfd, toClient);
							} 
							else if(validToUser==0){
								sprintf(toClient, "invalidToUser:%s",toUser);
								sendMessage(allClients[i].sockfd, toClient);
							}
						}
						else if(strcmp(part[0], "quit")==0){
							strcpy(toClient, "closing");
							sendMessage(allClients[i].sockfd, toClient);
							close (allClients[i].sockfd);
							if(len > 2){
								strcpy(allClients[i].username, allClients[len-1].username);
								allClients[i].sockfd = allClients[len-1].sockfd;
								allClients[i].queue = allClients[len-1].queue;
							}
							allClients[len-1].username[0] = '\0';
							allClients[len-1].sockfd = -1;
							len--;
						} 
						else if(strcmp(part[0], "getMessage")==0){
							if(dequeue(&allClients[i].queue, toClient)){
								sendMessage(allClients[i].sockfd, toClient);
							} else {
								strcpy(toClient, "noMessage");
								sendMessage(allClients[i].sockfd, toClient);
							}
						}
						else if(strcmp(part[0], "register")==0){
							int isReg = 0;
							if(allClients[i].username[0] != '\0'){
								strcpy(toClient,"ERROR");
								sendMessage(allClients[i].sockfd, toClient);
								break;
							}
							for(int j =1; j<len; j++){
								if(strncmp(allClients[j].username, part[1], MAX_USER_LEN)==0){
									strcpy(toClient, "userAlreadyRegistered");
									sendMessage(allClients[i].sockfd, toClient);
									isReg = 1;
									break;
								}
							}
							if(isReg == 0){
								strcpy(allClients[j].username, part[1]);
								strcpy(toClient, "registered");
								sendMessage(allClients[j].sockfd, toClient);
							}
						}
				}
				else if(retVal==3){
					close (allClients[i].sockfd);
					if(len > 2){
						
						strcpy(allClients[i].username, allClients[len-1].username);
						allClients[i].sockfd = allClients[len-1].sockfd;
						allClients[i].queue = allClients[len-1].queue;
					}
					allClients[len-1].username[0] = '\0';
					allClients[len-1].sockfd = -1;
					len--;
				}
				else{
					strcpy(toClient,"ERROR");
					sendMessage(allClients[i].sockfd, toClient);
				}			  
			}
			}
		}	
	}
}
}
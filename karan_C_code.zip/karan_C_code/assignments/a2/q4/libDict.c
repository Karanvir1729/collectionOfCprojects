#include<stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "libDict.h"

//#define DEBUG
#define DEBUG_LEVEL 3

#ifdef DEBUG
# define DEBUG_PRINT(x) printf x
#else
# define DEBUG_PRINT(x) do {} while (0)
#endif

#define DICT_INIT_ROWS 1024 
#define DICT_GROW_FACTOR 2
#define DICT_SHRINK_FACTOR 0.5
#define ROW_INIT_ENTRIES 8
#define ROW_GROW_FACTOR 2 
#define LINEAR_SEARCH_THRESHOLD 100 
#define PRIME1 77933 // a large prime
#define PRIME2 119557 // a large prime

/**
 * hash *c as a sequence of bytes mod m
 */
int dictHash(char *c, int m){
	int sum=0;
	while(*c!='\0'){
		int num = *c; 
		sum+= PRIME1*num+PRIME2*sum;
		c++;
	}
	if(sum<0)sum=-sum;
	sum = sum%m;
	return sum;
}
/**
 * put (key, value) in Dict
 * return 1 for success and 0 for failure
 */
int growDictPut(Dict *d, char *key, void *value){
	int h = dictHash(key, d->numRows);
	#ifdef DEBUG
	printf("dictPut(d,%s) hash=%d\n",key, h);
	dictPrint(d,DEBUG_LEVEL);
	#endif

	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif

	 if (d->rows[h].numEntries >= d->rows[h].capacity) {
            d->rows[h].capacity *= DICT_GROW_FACTOR;
			d->rows[h].entries = realloc(d->rows[h].entries, d->rows[h].capacity * sizeof(DictEntry));
			if (!d->rows[h].entries) {
				return 0;
			}
    }

	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif
	int low = 0;
	if(d->rows[h].numEntries < LINEAR_SEARCH_THRESHOLD){
		for (int i = 0; i < d->rows[h].numEntries; i++) {
			int cmp = strncmp(d->rows[h].entries[i].key, key,1024);
			if(cmp > 0){
				break;
			}
			low++;
		}
	}
	else{
		int high = d->rows[h].numEntries -1;
		while (low <= high) {
			int mid = (low + high) / 2;
			int cmp = strncmp(d->rows[h].entries[mid].key, key,1024);
			if (cmp < 0) {
				low = mid + 1;
			} else {
				high = mid - 1;
			}
		}
	}
    for (int i = d->rows[h].numEntries; i > low; i--) {
        d->rows[h].entries[i] = d->rows[h].entries[i - 1];
    }
    char *copy = strndup(key,1024);
    if (copy == NULL) {
        return 0;
    }
	
    d->rows[h].entries[low].key = copy;
    d->rows[h].entries[low].value = value;
    d->rows[h].numEntries++;
	if (d->rows[h].numEntries == d->rows[h].capacity) {
		d->numFullRows++;
	}
    #ifdef DEBUG
    dictPrint(d,DEBUG_LEVEL);
    #endif
    return 1;
}

/**
* Create a new Dict with a different number of rows.
* New number of rows = rows*factor
*/
void grow(Dict *d, int factor){
	int newNumRows = d->numRows*factor;
	//printf("Rows %d full %d \n", newNumRows, d->numFullRows);

	if(newNumRows <= 0){
		newNumRows = 1;
	}
	Dict *betterDict = dictNew(newNumRows);
	for (int i = 0; i < d->numRows; i++) {
        for (int j = 0; j < d->rows[i].numEntries; j++) {
			growDictPut(betterDict, d->rows[i].entries[j].key,d->rows[i].entries[j].value);
			free(d->rows[i].entries[j].key);
		}
		free(d->rows[i].entries);
	}
	free(d->rows);
	d->rows = betterDict->rows;
	d->numRows= betterDict->numRows;
	d->numFullRows = betterDict->numFullRows;
	d->numEmptyRows = betterDict->numEmptyRows;
	free(betterDict);
}
/**
 * Print the dictionary, 
 * level==0, dict header
 * level==1, dict header, rows headers
 * level==2, dict header, rows headers, and keys
 */
void dictPrint(Dict *d, int level){
	if(d==NULL){
		printf("\tDict==NULL\n");
		return;
	}
	printf("Dict\n");
	printf("\tnumRows=%d\n",d->numRows);
	if(level<1)return;

	for(int i=0;i<d->numRows;i++){
		printf("\tDictRow[%d]: numEntries=%d capacity=%d keys=[", i, d->rows[i].numEntries, d->rows[i].capacity);
		if(level>=2){
			for(int j=0;j<d->rows[i].numEntries;j++){
				printf("%s, ",d->rows[i].entries[j].key);
			}
		}
		printf("]\n");
	}
}
int dictGetIndex(Dict *d, char *key, int h){
	if(d->rows[h].numEntries < LINEAR_SEARCH_THRESHOLD){
		for (int i = 0; i < d->rows[h].numEntries; i++) {
			if (strncmp(d->rows[h].entries[i].key, key,1024) == 0) {
				return i;
			}
		}
	}
	else{
		int low = 0;
		int high = d->rows[h].numEntries-1; 
		while (low <= high) {
			int mid = (low + high) / 2;
			int cmp = strncmp(d->rows[h].entries[mid].key, key,1024);
			if (cmp == 0) {
				return mid;
			} else if (cmp < 0) {
				low = mid + 1;
			} else {
				high = mid - 1;
			}
		}
	}
	return -1;
}

/**
 * Return the DictEntry for the given key, NULL if not found.
 * This is so we can store NULL as a value.
 */
DictEntry *dictGet(Dict *d, char *key){

	int h = dictHash(key, d->numRows);
	int index = dictGetIndex(d, key, h);
	if(index != -1){
		return &d->rows[h].entries[index];
	}
    return NULL;
}

/**
 * Delete key from dict if its found in the dictionary
 * Returns 1 if found and deleted
 * Returns 0 otherwise
 */
int dictDel(Dict *d, char *key){
	// find row
	int h=dictHash(key, d->numRows);
	
	#ifdef DEBUG
	printf("dictDel(d,%s) hash=%d\n",key, h);
	dictPrint(d,DEBUG_LEVEL);
	#endif
	int index = dictGetIndex(d, key, h);
	if(index != -1){
		free(d->rows[h].entries[index].key);
		// Move everything over
		for (int j = index; j < d->rows[h].numEntries -1; j++) {
			d->rows[h].entries[j] = d->rows[h].entries[j+1];
		}
		d->rows[h].entries[d->rows[h].numEntries-1].key = NULL;
		d->rows[h].entries[d->rows[h].numEntries-1].value = NULL;
		d->rows[h].numEntries--;
		// if (d->rows[h].numEntries < d->rows[h].capacity*0.75) {
		// 	d->numFullRows--;
		// 	if(d->numFullRows < 0){
		// 		d->numFullRows = 0;
		// 	}
		// }
		if (d->rows[h].numEntries == 0) {
			d->numEmptyRows++;
		}
		if (d->numEmptyRows > d->numRows*0.4) {
			//printf("Rows %d full %d \n", d->numRows, d->numFullRows);
			grow(d, DICT_SHRINK_FACTOR);
		}
		
		return 1;
	}
	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif

	return 0;
}

/**
 * put (key, value) in Dict
 * return 1 for success and 0 for failure
 */
int dictPut(Dict *d, char *key, void *value){
	int h = dictHash(key, d->numRows);
	#ifdef DEBUG
	printf("dictPut(d,%s) hash=%d\n",key, h);
	dictPrint(d,DEBUG_LEVEL);
	#endif

	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif

	if (d->rows[h].numEntries >= d->rows[h].capacity) {
            d->rows[h].capacity *= DICT_GROW_FACTOR;
			d->rows[h].entries = realloc(d->rows[h].entries, d->rows[h].capacity * sizeof(DictEntry));
			if (!d->rows[h].entries) {
				return 0;
			}
    }
	if (d->rows[h].numEntries < d->rows[h].capacity*0.25 && d->rows[h].capacity >= 4) {
            d->rows[h].capacity *= DICT_SHRINK_FACTOR;
			d->rows[h].entries = realloc(d->rows[h].entries, d->rows[h].capacity * sizeof(DictEntry));
			if (!d->rows[h].entries) {
				return 0;
			}
    }
	
	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif
	int low = 0;
	if(d->rows[h].numEntries < LINEAR_SEARCH_THRESHOLD){
		for (int i = 0; i < d->rows[h].numEntries; i++) {
			int cmp = strncmp(d->rows[h].entries[i].key, key, 1024);
			if(cmp == 0){
				d->rows[h].entries[i].value = value;
				return 1;
			}
			else if(cmp > 0){
				break;
			}
			low++;
		}
	}
	else{
		int high = d->rows[h].numEntries -1;
		while (low <= high) {
			int mid = (low + high) / 2;
			int cmp = strncmp(d->rows[h].entries[mid].key, key, 1024);
			if(cmp == 0){
				d->rows[h].entries[mid].value = value;
				return 1;
			}
			else if (cmp < 0) {
				low = mid + 1;
			} else {
				high = mid - 1;
			}
		}
	}
    for (int i = d->rows[h].numEntries; i > low; i--) {
        d->rows[h].entries[i] = d->rows[h].entries[i - 1];
    }
    char *copy = strndup(key,1024);
    if (copy == NULL) {
        return 0;
    }
	
    d->rows[h].entries[low].key = copy;
    d->rows[h].entries[low].value = value;
    d->rows[h].numEntries++;
	if (d->rows[h].numEntries >= d->rows[h].capacity) {
		d->numFullRows++;
	}
	
	if(d->numFullRows > 1){
		grow(d, DICT_GROW_FACTOR);
	}

    #ifdef DEBUG
    dictPrint(d,DEBUG_LEVEL);
    #endif
    return 1;
}


/**
 * free all resources allocated for this Dict. Everything, and only those things
 * allocated by this code should be freed.
 */
void dictFree(Dict *d){
	
	for (int i = 0; i < d->numRows; i++) {
		// free all the keys we allocated in row 
        for (int j = 0; j < d->rows[i].numEntries; j++) {
			free(d->rows[i].entries[j].key);
		}
		free(d->rows[i].entries);
	}
	free(d->rows);
	free(d);
	
}

/**
 * Allocate and initialize a new Dict. Initially this dictionary will have initRows
 * hash slots. If initRows==0, then it defaults to DICT_INIT_ROWS
 * Returns the address of the new Dict on success
 * Returns NULL on failure
 */
Dict * dictNew(int initRows){
	if (initRows == 0){
		initRows = DICT_INIT_ROWS;
	}
	Dict *d = malloc(sizeof(Dict));
    if (!d) {
        return NULL; // malloc failed, return NULL
    }
	d->numRows = initRows;
	d->rows =  malloc(initRows * sizeof(DictRow));
	d->numFullRows = 0;
	d->numEmptyRows = 0;

	for (int i = 0; i < d->numRows; i++) {
		d->rows[i].numEntries = 0;
		d->rows[i].capacity = ROW_INIT_ENTRIES;
		d->rows[i].entries =  malloc(ROW_INIT_ENTRIES * sizeof(DictEntry));
		if (!d->rows[i].entries) {
        return NULL; // malloc failed, return NULL
    	}
	}

	return d;
}


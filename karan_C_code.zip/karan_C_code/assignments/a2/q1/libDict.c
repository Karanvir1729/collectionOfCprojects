#include<stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "libDict.h"

#define DEBUG
#define DEBUG_LEVEL 3

#ifdef DEBUG
# define DEBUG_PRINT(x) printf x
#else
# define DEBUG_PRINT(x) do {} while (0)
#endif

#define DICT_INIT_ENTRIES 8
#define DICT_GROW_FACTOR 2 

/**
 * Print the dictionary, 
 */
void dictPrint(Dict *d, int level){
	if(d==NULL){
		printf("\tDict==NULL\n");
		return;
	}
	printf("\tDict: numEntries=%d capacity=%d [", d->numEntries, d->capacity);
	if(level>=2){
		for(int j=0;j<d->numEntries;j++){
			printf("(%s,%d), ",d->entries[j].key, d->entries[j].value);
		}
	}
	printf("]\n");
}

/**
 * Return the DictEntry for the given key, NULL if not found.
 */
DictEntry *dictGet(Dict *d, char *key){
	
	// find key in row
	for (int i = 0; i < d->numEntries; i++) {
        if (strncmp(d->entries[i].key, key,1024) == 0) {
			return &d->entries[i];
		}
	 }
	return NULL;
}

/**
 * Delete key from Dict if its found in the dictionary
 * Returns 1 if found and deleted
 * Returns 0 otherwise
 */
int dictDel(Dict *d, char *key){
	#ifdef DEBUG
	printf("dictDel(d,%s)\n",key);
	dictPrint(d,DEBUG_LEVEL);
	#endif
	// key[1024]= '\0'; //Now the string must have a terminator at some point. 
	// if (strlen(key) > 1024) {
    // return 0; // string is too long
	// }
	
	//find key
	for (int i = 0; i < d->numEntries; i++) {
		if (strncmp(d->entries[i].key, key,1024) == 0) {
			// free key
			//printf("(%s,%d), ",d->entries[i].key, d->entries[i].value);
			free(d->entries[i].key);
			// Move everything over
			for (int j = i; j < d->numEntries -1; j++) {
				d->entries[j] = d->entries[j+1];
			}
			d->entries[d->numEntries-1].key = NULL;
			d->entries[d->numEntries-1].value = -1;
			d->numEntries--;
			return 1;
		}
	}
	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif

	return 0;
}

/**
 * put (key, value) in Dict
 * return 1 for success and 0 for failure
 */
int dictPut(Dict *d, char *key, int value){
	#ifdef DEBUG
	printf("dictPut(d,%s)\n",key);
	dictPrint(d,DEBUG_LEVEL);
	#endif
	// key[1024]= '\0'; //Now the string must have a terminator at some point. 
	// if (strlen(key) > 1024) {
    // return 0; // string is too long
	// }
	// If key is already here, just replace value
	// if(!is_safe(key)){
	// 	return 0;
	// }
	DictEntry *entry = dictGet(d, key);
    if (entry != NULL) {
        entry->value = value;
		return 1;
    }

	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif
	/** 
	 * At this point we know the key is not in Dict, so we 
	 * need to place (key, value) as a new entry in this 
	 *
	 * if there is no space, expand the row
	 */

	 //Check to find space
	if (d->numEntries >= d->capacity) {
            d->capacity *= DICT_GROW_FACTOR;
			d->entries = realloc(d->entries, d->capacity * sizeof(DictEntry));
			if (!d->entries) {
				return 0;
			}
    }
	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif
	
	/** 
	 * We now know we have space.
	 * This is a new key for this row, so we want to place (key, value)
	 *
	 * In python only immutables can be hash keys. If the user can change the key sitting
	 * in the Dict, then we won't be able to find it again. We solve this problem here
	 * by copying keys using strdup.
	 * 
	 */
	
	char *copy = strndup(key,1024);
	if (copy == NULL) {
        return 0;
    }
	d->entries[d->numEntries].key = copy;
	d->entries[d->numEntries].value = value;
	d->numEntries++;

	#ifdef DEBUG
	dictPrint(d,DEBUG_LEVEL);
	#endif

	return 1;
}

/**
 * free all resources allocated for this Dict. Everything, and only those things
 * allocated by this code should be freed.
 */
void dictFree(Dict *d){
	// free all the keys we allocated
	 for (int i = 0; i < d->numEntries; i++) {
		free(d->entries[i].key);
    }
	// free the array of DictEntry
	free(d->entries);

	// free Dict
	free(d);
}

/**
 * Allocate and initialize a new Dict. 
 * Returns the address of the new Dict on success
 * Returns NULL on failure
 */
Dict * dictNew(){
	Dict *d = malloc(sizeof(Dict));
	// Create the Dict and initialize it
	if (!d) {
		return NULL; // malloc failed, return NULL
	}
	d->numEntries = 0;
	d->capacity   = DICT_INIT_ENTRIES;
	d->entries =  malloc(DICT_INIT_ENTRIES * sizeof(DictEntry));
	if (d->entries == NULL) {
        free(d);
        return NULL;
    }

	for (int i = 0; i < d->numEntries; i++) {
		d->entries[i].key = NULL;
		d->entries[i].value = -1;
	}
	return d;
	
}


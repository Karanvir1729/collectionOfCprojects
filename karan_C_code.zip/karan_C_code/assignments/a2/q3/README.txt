This directory is for q3

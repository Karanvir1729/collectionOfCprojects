#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/stat.h>

#include "libParseArgs.h"
#include "libProcessControl.h"

/**
 * parallelDo -n NUM -o OUTPUT_DIR COMMAND_TEMPLATE ::: [ ARGUMENT_LIST ...]
 * build and execute shell command lines in parallel
 */

/**
 * create and return a newly malloced command from commandTemplate and argument
 * the new command replaces each occurrance of {} in commandTemplate with argument
 */
char *createCommand(char *commandTemplate, char *argument){
	size_t lenCommandTemplate = strlen(commandTemplate) + 1;
	size_t lenArgument = strlen(argument) + 1;
	char *command= (char *) malloc(lenCommandTemplate);
	if (command == NULL) {
        perror("Error: memory allocation failed\n");
        exit(1);
    }
	size_t i = 0, j = 0;
	while (commandTemplate[i] != '\0') {
		if(commandTemplate[i] == '{' && commandTemplate[i+1] == '}'){
			char *temp = realloc(command, j + lenArgument);
			if (temp == NULL) {
				perror("Error: memory allocation failed\n");
        		exit(1);
    		}
			command = temp;
            strncpy(&command[j], argument, lenArgument-1);
			j += lenArgument-1;
            i += 2;
		}
		else{
			command[j] = commandTemplate[i];
            j++;
            i++;
        }
	}
	command[j] = '\0';
    return command;
}

typedef struct PROCESS_STRUCT {
	int pid;
	int ifExited;
	int exitStatus;
	int status;
	char *command;
} PROCESS_STRUCT;

typedef struct PROCESS_CONTROL {
	int numProcesses;
	int numRunning; 
	int maxNumRunning;
	int numCompleted;
	PROCESS_STRUCT *process;
} PROCESS_CONTROL;

PROCESS_CONTROL processControl;

void printSummary(){
	printf("%d %d %d\n", processControl.numProcesses, processControl.numCompleted, processControl.numRunning);
}
void printSummaryFull(){
    printSummary();
    int i=0, numPrinted=0;
    while(numPrinted<processControl.numCompleted && i<processControl.numProcesses){
        if(processControl.process[i].ifExited){
            printf("%d %d %d %s\n",
            processControl.process[i].pid,
            processControl.process[i].ifExited,
            processControl.process[i].exitStatus,
            processControl.process[i].command);
            numPrinted++;
        }
        i++;
    }
}

/**
 * find the record for pid and update it based on status
 * status has information encoded in it, you will have to extract it
 */
void updateStatus(int pid, int status){
	 for (int i = 0; i < processControl.numProcesses; i++) {
        if (processControl.process[i].pid == pid) {
            processControl.process[i].status = status;
            if (WIFEXITED(status)) {
                processControl.process[i].ifExited = 1;
                processControl.process[i].exitStatus = WEXITSTATUS(status);
            }
            else{
                processControl.process[i].ifExited = 1;
                processControl.process[i].exitStatus = -1;
            }
            break;
        }
    }
}

void handler(int signum){
	if (signum == SIGUSR1){
        printSummary();
    }
    else{
        printSummaryFull();
    }
}
/**
 * This function does the bulk of the work for parallelDo. This is called
 * after understanding the command line arguments. runParallel 
 * uses pparams to generate the commands (createCommand), 
 * forking, redirecting stdout and stderr, waiting for children, ...
 * Instead of passing around variables, we make use of globals pparams and
 * processControl. 
 */
 int runParallel(){
    struct stat st = {0};
    if (stat(pparams.outputDir, &st) == -1) {
        if (mkdir(pparams.outputDir, 0755) != 0) {
            perror("Error: failed to create output directory\n");
            exit(1);
        }
    }
    processControl.process = (PROCESS_STRUCT *) malloc(pparams.argumentListLen * sizeof(PROCESS_STRUCT));
    if (processControl.process == NULL) {
        perror("Error: memory allocation failed\n");
        exit(1);
    }

    processControl.numProcesses = pparams.argumentListLen;
    processControl.numRunning = 0;
    processControl.maxNumRunning = pparams.maxNumRunning;
    processControl.numCompleted = 0;
    
    // Using createCommand to create executable commad for each argument
    for(int i = 0; i < pparams.argumentListLen; i++){
        char *command = createCommand(pparams.commandTemplate, pparams.argumentList[i]);

        pid_t pid = fork();
        
        if (pid < 0) {
            perror("Error: fork failed\n");
            exit(1);
        }
        // Inside a child
        else if (pid == 0) {

            // Redirect stdout and stderr to respective files in outputDir
            char stdout_filename[256];
            snprintf(stdout_filename, sizeof(stdout_filename), "%s/%d.stdout", pparams.outputDir, getpid());
            int stdout_fd = open(stdout_filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (stdout_fd < 0) {
                perror("Error: open failed\n");
                exit(1);
            }
            if (dup2(stdout_fd, STDOUT_FILENO) < 0) {
                perror("Error: dup2 failed\n");
                exit(1);
            }
            close(stdout_fd);

            char stderr_filename[256];
            snprintf(stderr_filename, sizeof(stderr_filename), "%s/%d.stderr", pparams.outputDir, getpid());
            int stderr_fd = open(stderr_filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (stderr_fd < 0) {
                fprintf(stderr, "Error: open failed on PID %d\n", getpid());
                exit(1);
            }
            if (dup2(stderr_fd, STDERR_FILENO) < 0) {
                fprintf(stderr, "Error: dup2 failed on PID %d\n", getpid());
                exit(1);
            }
            close(stderr_fd);

            char *args[] = {"/bin/bash", "-c", command, NULL};
            execvp(args[0], args);

            fprintf(stderr, "Error: exec failed on PID %d\n", getpid());
            exit(1);
        }
        else {
            // Parent process
            processControl.process[i].pid = pid;
            processControl.process[i].ifExited = 0;
            processControl.process[i].exitStatus = -1;
            processControl.process[i].status = 0;
            processControl.process[i].command = command;
            processControl.numRunning++;
            
            // Check if too many running
            while (processControl.numRunning >= processControl.maxNumRunning) {
                int pid, status;
                pid = wait(&status);
                if (pid > 0) {
                    updateStatus(pid, status);
                    processControl.numRunning--;
                    processControl.numCompleted++;
                }
                else {
                    exit(1);
                }
            }
            signal(SIGUSR1, handler);
            signal(SIGUSR2, handler);
        }
    }
    
    // Wait for all child processes to complete
    while (processControl.numCompleted < processControl.numProcesses) {
        int pid, status;
        pid = wait(&status);
        if (pid > 0) {
            updateStatus(pid, status);
            processControl.numRunning--;
            processControl.numCompleted++;
        }
        else {
            exit(1);
        }
    }

    // Print the summary of process status
    printSummaryFull();
     for(int i=0; i<processControl.numProcesses; i++){
        free(processControl.process[i].command);
    }
    free(processControl.process);
    return 0;
}
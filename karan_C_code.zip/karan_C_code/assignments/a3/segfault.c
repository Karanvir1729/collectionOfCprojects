#include<stdio.h>
int main(int argc, char *argv[]){
	int *p;
	while(1)*p++=*p;
}
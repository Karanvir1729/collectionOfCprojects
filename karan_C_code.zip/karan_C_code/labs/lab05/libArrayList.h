/**
 * size: from users perspective, elements[0], ..., elements[size-1] 
 * are all of the integers in the ArrayList
 *
 * capacity: is the total number of integers available at elements
 * that is elements[0], ..., elements[size-1], ... , elements[capacity-1] 
 * are all available to take integer values. 
 */
typedef struct {
	int size; 
	int capacity; 
	int *elements; // pointer to a block of capacity integers
} ArrayList;

/**
 * Return value of integer at position index, if 0<=index<a->size
 * Return 0, otherwise
 */
int alGet(ArrayList *a, int index);

/**
 * put value at position index if 0<=index<a->size
 * return 1 for success and 0 for failute
 */
int alSet(ArrayList *a, int index, int value);

/**
 * put value as the new last value in the ArrayList
 * growing the ArrayList if necessary
 * Return 1 if success, 0 otherwise
 */
int alAdd(ArrayList *a, int value);

/**
 * Allocate and initialize a new ArrayList
 * Returns the address of the new ArrayList if everything is OK
 * Returns NULL if anything goes wrong
 */
ArrayList * alNew();


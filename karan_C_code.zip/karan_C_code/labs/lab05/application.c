#include <stdio.h>
#include <stdlib.h>
#include "libArrayList.h"

void printAL(ArrayList *al){
	printf("size=%d\ncapacity=%d\n",al->size, al->capacity);
	printf("elements-->[");
	for(int i=0;i<al->size;i++){
		printf("%d,",al->elements[i]);
	}
	for(int i=al->size; i<al->capacity; i++){
		printf("????,");
	}
	printf("]\n\n");
}

int main(int argc, char **argv){
	ArrayList *al=alNew();
	int i;
	for(i=0;i<21;i++){
		alAdd(al,i*i);
	}
	printAL(al);
	for(i=0;i<10;i++){
		alSet(al,i,i);
	}
	printAL(al);
	for(i=21;i<40;i++){
		alAdd(al,i);
	}
	printAL(al);
}

/* server process */

/* include the necessary header files */
#include<ctype.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<unistd.h>
#include<time.h>


#define SIZE sizeof(struct sockaddr_in)

int newsockfd;

int main (int argc, char *argv[]) {
    int sockfd;

    char c;

  /* initialize the internet socket with a port number of 7001
       and the local address,specified as INADDR_ANY */
    struct sockaddr_in server;
    server.sin_family=AF_INET;
    server.sin_addr.s_addr=INADDR_ANY;
    server.sin_port = htons(7001);

    /* set up the transport end point */
    if ((sockfd = socket (AF_INET, SOCK_STREAM, 0)) == -1) {
        perror ("socket call failed");
        exit (1);
    }


    /* "bind server address to the end point */
    if (bind (sockfd, (struct sockaddr *) &server, SIZE) == -1) {
        perror ("bind call failed");
        exit (1);
    }

    /* start listening for incoming connections */
    if (listen (sockfd, 5) == -1) {
        perror ("listen call failed");
        exit (1);
    }



    for (;;) {
        /*accept a connection */
        if ((newsockfd = accept (sockfd, NULL, NULL)) == -1) {
            perror ("accept call failed");
            continue;
        }

        /* spawn a child to deal with the connection */
        if (fork () == 0) {
            FILE *fp;
            char buf[1024]; // space for input, at most 1024 characters
            int secret = 0;            

	
            if ((fp=fdopen(newsockfd, "r+"))!=NULL) {
		    char buffer[1024];
            char buf[1024];
            char *question = "Do you want to play (y/n)?\n\0";
            char *gamePlay = "I am thinking of a number between 1 and 100, can you guess it?\nGuess:\n\0";
            char *correct = "Your guess of %d is correct\n\0";

            fputs(question, fp);
            fgets(buffer,sizeof(buffer),fp);

            while(buffer[0] == 'y'){

                srand(time(NULL));
                secret = 1+rand()%100;

                fputs(gamePlay, fp);

                while (fgets(buf, sizeof(buf), fp)){
                    int guess = atoi(buf);
                    if(guess == secret){
                        fprintf(fp, "Your guess of %d is correct\n",guess);
                        break;
                    }
                    if(guess < secret){
                        fprintf(fp, "Your guess of %d is low\nGuess:\n",guess);
                        
                        
                    }
                    if(guess > secret){
                        fprintf(fp, "Your guess of %d is high\nGuess:\n",guess);
                        
                    }
                }
                fputs(question, fp);
                fgets(buffer,sizeof(buffer),fp);
            }
            fclose(fp);
        } else {
            close (newsockfd);
        }
        }
        exit (0);
    }
}

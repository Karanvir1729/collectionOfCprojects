#!/bin/bash

echo "The number of arguments=$#"
echo "command=$0"
echo "first argument=$1"
echo "second argument=$2"

echo "shift pops off $1 and shifts everything 'down'"
while (( $# > 0))
do
	echo $1
	shift
done;


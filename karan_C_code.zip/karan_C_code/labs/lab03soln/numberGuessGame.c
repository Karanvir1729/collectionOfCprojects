#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
	char buf[1024]; // space for input, at most 1024 characters
	int secret = 0;
	int numGuesses = 0;

	srand(time(NULL));
	secret = 1+rand()%10;

	printf("I am thinking of a number between 1 and 10, can you guess it?\n");

	while(1){
		printf("Guess: ");
		fgets(buf, sizeof(buf), stdin); 
		int guess = atoi(buf);
		numGuesses+=1;
		if(guess == secret){
			printf("%d is correct, you guessed it in %d guesses\n",guess, numGuesses);
			break;
		}
		if(guess < secret){
			printf("%d is too low.  %d guesses\n",guess, numGuesses);
		}
		if(guess > secret){
			printf("%d is too high. %d guesses\n",guess, numGuesses);
		}
	}
}

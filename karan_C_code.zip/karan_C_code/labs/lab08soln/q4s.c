#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<stdlib.h> // exit

int main(int argc, char ** argv){
	int isParent = 1;

	pid_t pid = getpid(); // my pid
	pid_t ppid= getppid(); // my parents pid (probably bash running in the terminal)

	printf("Parent (pid=%d): My parent is ppid=%d\n", pid, ppid);
	printf("Parent (pid=%d): One process so far...\n", pid);
	printf("Parent (pid=%d): Thats about to change...\n", pid);

	for(int i=0;i<2;i++){
		pid_t child_pid=fork(); 
		
		if(child_pid==0){
			pid = getpid(); // I have a new pid
			ppid = getppid(); // Here is my parent
			printf("Child (pid=%d): My parent is ppid=%d\n", pid, ppid);
			isParent=0;
			break;
		} else if(child_pid>0) {
			printf("Parent (pid=%d): child_pid=%d\n", pid, child_pid);
	
	
		} else {
			printf("Fork error, no child.\n");
		}
	}

	sleep(10); // Everyone sleeps

	if(isParent){
		printf("Parent (pid=%d): waiting for my children \n", pid);
		for(int i=0;i<2;i++){
			int child_status;
			pid_t child_pid=wait(&child_status); // child_status now encodes information about the child
                	printf("Parent (pid=%d): child pid=%d status=%d exit status=%d\n",pid, child_pid, child_status, WEXITSTATUS(child_status));
                	if(WIFEXITED(child_status)){
                		printf("Parent (pid=%d): child pid=%d exited successfully\n", pid, child_pid);
                	} else {
				printf("Parent (pid=%d): child pid=%d state changed for some other reason\n", pid, child_pid);
			}
		}
		printf("Parent (pid=%d): exiting\n", pid);
		exit(0);
	} else {
		printf("Child (pid=%d): exiting\n", pid);
		exit(7);
	}
}


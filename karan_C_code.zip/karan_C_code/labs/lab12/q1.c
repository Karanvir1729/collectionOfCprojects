#include<stdio.h>
// What does the following do?
// Fix it.

void inc(int i){
    i=i+1;
    return;
}

int main(int argc, char**argv){
    int j=7;
    inc(j);
    printf("%d\n", j);
}

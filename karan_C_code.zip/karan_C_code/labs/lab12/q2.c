
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/** 
 * Simulate 
 * /usr/bin/find . -print | /usr/bin/grep -ie 'joe' > stuffFound
 *
 * the return code form this should be the return code from grep 
 * assume all system calls succeed, so you don't need to perror
 *
 * use only 1 fork
 */
int main(int argc, char ** argv){

}


#include <stdio.h>
#include <stdlib.h>

int get_my_number(){

    int c = 1;
    int d = 2;
    int e = 6;
    int my_num = c * d * e;

    return my_num;
}



int main(void){

    int a = 12;
    int b = get_my_number();
    if (a == b) {
        printf("My numbers are the same\n");
    } else {
        printf("My numbers are not the same\n");
    }
    return 0;
}


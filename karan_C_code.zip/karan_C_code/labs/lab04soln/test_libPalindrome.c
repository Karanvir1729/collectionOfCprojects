#include <stdio.h>
#include <stdlib.h>
#include "libPalindrome.h" // C requires declare before use !!

/**
 * Check whether the call to isPalindrome(s)==eRetVal (what we expected)
 */
void check(char *s, int eRetVal){
	int retVal = 0;
	char *mess;
        char *ok="OK ";
        char *err="ERR";

	retVal = isPalindrome(s);
	if(retVal==eRetVal)mess=ok;
	else mess=err;

	printf("%s (return) = (%d) EXPECTED (%d) isPalindrome(%s)\n", mess, eRetVal, retVal, s);
}

/**
 * Check whether the call to isPalindrome(s)==eRetVal (what we expected)
 * A more advanced version of the above
 */
void check_advanced(char *s, int eRetVal){
	char *mess[]= {"ERR", "OK "};
	int retVal = isPalindrome(s);
	printf("%s (return) = (%d) EXPECTED (%d) isPalindrome(%s)\n", mess[retVal==eRetVal], eRetVal, retVal, s);
}

int main(int argc, char *argv[]) {
	check("", 1);
	check("a", 1);
	check("ab", 0);
	check("aba", 1);
	check("abba", 1);
	check("rats live on no evil star", 1);
	check("Zrats live on no evil star", 0);
	check("rZats live on no evil star", 0);
	check("rats livZe on no evil star", 0);
	check("rats livZe on no eZvil star", 1);
	check("definitely not a palindrome", 0);
	return(0);
}

#include "libPalindrome.h"

/**
 * return whether the null terminated string is a palindrome, 
 * that is reads the same way forwards and backwards.
 */
int isPalindrome(char *s){
	char *cp1=s;
	char *cp2=s;

	// empty strings are palindromes
	if(*s=='\0')return(1);

	// find the end of the string
	cp2=s;
	while(*cp2!='\0')cp2++;
	cp2--;

	// NOTE: We are relying on how strings are layed out in memory
	cp1=s;
	while(cp1<cp2 && *cp1==*cp2){
		cp1++; cp2--;
	}
	if(cp1>=cp2)return(1);
	else return(0);
}

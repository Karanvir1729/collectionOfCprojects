#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int main(int argc, char *argv[]){

	char buf[1024]; // space for input, at most 1024 characters
	int num = 0;
	
	srand(time(NULL)); // seed the random number generator
	int r = 1+rand()%10;
	
	printf("I am thinking of a number between 1 and 10, can you guess it?\n");
	printf("Guess: ");
	fgets(buf, sizeof(buf), stdin);
	num = atoi(buf);
	int guesses = 1;
	while (num != r){
		if (num < r){
			printf( "%d is too low. %d guesses\n",num,guesses);
		}
		else{
			printf( "%d is too high. %d guesses\n",num,guesses);
		}
		guesses++;
		printf("I am thinking of a number between 1 and 10, can you guess it?\n");
		printf("Guess: ");
		fgets(buf, sizeof(buf), stdin);
		num = atoi(buf);
	}
	printf("%d is correct, you guessed it in %d guesses\n", num, guesses);
}

#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(int argc, char *argv[]){
	char buf[1024]; // space for input, at most 1024 characters
	int num = 0;

	srand(time(NULL)); // seed the random number generator
	printf("How many random numbers do you want? ");
	fgets(buf, sizeof(buf), stdin);              // read at most 1024 characters into buf
	num = atoi(buf);                             // like int(buf) in python, try man atoi
	printf("Here are %d random numbers between 1 and 100\n", num); // print("Here are {} random numbers\n".format(num))
	for(int i=0;i<num;i++){
		int r = 1+rand()%100;
		printf("Random number %d is %d\n",i,r);
	}
}

#include<stdio.h>

/**
 * return whether the users input is a palindrome, 
 * that is reads the same way forwards and backwards.
 */
int main(int argc, char *argv[]){
	char buf[1024]; // space for input, at most 1024 characters
	int i1=0, i2=0;
	printf("Your string please: ");
	fgets(buf, sizeof(buf), stdin); 

	// strings in C are '\0' (aka NULL) terminated.
	// fgets includes the newline in the string!!
	// lets remove it by ending the string at the '\n' character
	
	while(buf[i2]!='\0' && buf[i2]!='\n'){
		i2++;
	}
	buf[i2]='\0';

	 int i;
    for (i = 0; i < i2 / 2; i++) {
        if (buf[i] != buf[i2 - i - 1]) {
             printf("%s is not a palindrome\n",buf);
			 return;
        }
    }
    printf("%s is a palindrome\n",buf);

	// printf("%s is a palindrome\n",buf);
	// printf("%s is not a palindrome\n",buf);
}

int isPalindrome(char *s);

#!/bin/bash
# The following is a script to build everything in this directory
# BUT instead you can just use 
# make clean
# make palindrome
# make test_libPalindrome

# The library code
gcc -c libPalindrome.c          # generate libPalindrome.o

# code which uses the library code
gcc -c test_libPalindrome.c     # generate test_libPalindrome.o 
gcc -c palindrome.c             # generate palindrome.o

# the final executables, created from the pieces linked together
gcc -o test_libPalindrome test_libPalindrome.o libPalindrome.o
gcc -o palindrome palindrome.c libPalindrome.o


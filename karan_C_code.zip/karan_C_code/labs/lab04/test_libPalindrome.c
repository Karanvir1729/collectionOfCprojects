#include <stdio.h>
#include <stdlib.h>
#include "libPalindrome.h" // C requires declare before use !!

/**
 * Check whether the call to isPalindrome(s)==eRetVal (what we expected)
 */
void check(char *s, int eRetVal){
	int retVal = 0;
	char *mess;
        char *ok="OK ";
        char *err="ERR";

	retVal = isPalindrome(s);
	if(retVal==eRetVal)mess=ok;
	else mess=err;

	printf("%s (return) = (%d) EXPECTED (%d) isPalindrome(%s)\n", mess, retVal, eRetVal, s);
}

/**
 * Check whether the call to isPalindrome(s)==eRetVal (what we expected)
 * A more advanced version of the above
 */
void check_advanced(char *s, int eRetVal){
	char *mess[]= {"ERR", "OK "};
	int retVal = isPalindrome(s);
	printf("%s (return) = (%d) EXPECTED (%d) isPalindrome(%s)\n", mess[retVal==eRetVal], retVal, eRetVal, s);
}

int main(int argc, char *argv[]) {
	// check("", 1);
	// check("a", 1);
	// check("ab", 0);
	// check("aba", 1);
	// check("abba", 1);
	// check("rats live on no evil star", 1);
	// check("Zrats live on no evil star", 0);
	// check("rZats live on no evil star", 0);
	// check("rats livZe on no evil star", 0);
	// check("rats livZe on no eZvil star", 1);
	// check("definitely not a palindrome", 0);
	// return(0);
	int i = 7, j = i;
	int *pt = &i;
	*pt = 9;
	printf("Value of i: %d\n", i); // 9
	printf("Value of j: %d\n", j); // 7
	printf("Value of j | (i+1): %d\n", j ^ *pt++); // 14
	printf("pt points to %d\n", ++*pt); // 0
	
	char utm_local[] = "erindale";
	char utm_city[] = "mississauga";
	char utsg_local[] = "st. george";
	char utsg_city[] = "toronto";
	printf("The address of utm_local is %p\n", (void*) &utm_local);
    printf("The address of utm_city is %p\n", (void*) &utm_city);
    printf("The address of utsg_local is %p\n", (void*) &utsg_local);
    printf("The address of utsg_city is %p\n", (void*) &utsg_city);
	printf("llllllllllllllllllllllllll");
	utm_city[4] = '\0'; // utm_city is now "miss"
	printf("The address of utm_local is %p\n", (void*) &utm_local);
    printf("The address of utm_city is %p\n", (void*) &utm_city);
    printf("The address of utsg_local is %p\n", (void*) &utsg_local);
    printf("The address of utsg_city is %p\n", (void*) &utsg_city);
	printf("llllllllllllllllllllllllll");
	utm_local[8] = 'i'; // what happens to utm_local?
	printf("The address of utm_local is %p\n", (void*) &utm_local);
    printf("The address of utm_city is %p\n", (void*) &utm_city);
    printf("The address of utsg_local is %p\n", (void*) &utsg_local);
    printf("The address of utsg_city is %p\n", (void*) &utsg_city);
	printf("llllllllllllllllllllllllll");
	utsg_local[10] = 'k'; // what about now?
	printf("The address of utm_local is %p\n", (void*) &utm_local);
    printf("The address of utm_city is %p\n", (void*) &utm_city);
    printf("The address of utsg_local is %p\n", (void*) &utsg_local);
    printf("The address of utsg_city is %p\n", (void*) &utsg_city);

return 0;

}

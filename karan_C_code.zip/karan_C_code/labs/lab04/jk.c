#include <stdio.h>

int main(void) {
  int i = 7, j = i;
  int *pt = &i;
  *pt = 9;
  printf("Value of i: %d\n", i); // 9
  printf("Value of j: %d\n", j); // 7
  printf("Value of j | (i+1): %d\n", j ^ *pt++); // 14
  printf("pt points to %d\n", ++*pt); // 0
  return 0;
}
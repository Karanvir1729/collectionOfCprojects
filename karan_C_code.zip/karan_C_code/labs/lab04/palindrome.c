#include<stdio.h>
#include "libPalindrome.h"

/**
 * return whether the users input is a palindrome, 
 * that is reads the same way forwards and backwards.
 */
int main(int argc, char *argv[]){
	char buff[1024]; // space for input, at most 1024 characters
	char *cp;

	printf("Your string please: ");
	fgets(buff, sizeof(buff), stdin); // read a line from stdin (could have a \n\0 at the end).
	
	// Change the \n to \0 since isPalindrome expects null terminated strings
	cp = buff;
	while(*cp != '\0' && *cp!='\n') cp++;
	*cp='\0';

	if(isPalindrome(buff))printf("%s is a palindrome\n",buff);
	else printf("%s is not a palindrome\n",buff);
}

#include "libPalindrome.h"

/**
 * return whether the null terminated string is a palindrome, 
 * that is reads the same way forwards and backwards.
 */
int isPalindrome(char *s){
	char *i1, *i2;
	i1 = s;
	i2 = s;
	while(*i2!='\0'){
		i2++;
	}
	i2--;

	while(i1<i2 && *i2==*i1){ // Note: order matters here!
		i1++; i2--;
	}
	if(i1>=i2)return(1);
	else return(0);
}

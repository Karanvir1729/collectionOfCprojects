#include<stdio.h>
#include<signal.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h> // exit
int main(int argc, char **argv){

	pid_t pid;
	printf("One process so far...\n");
	printf("Thats about to change...\n");

	pid=fork(); // (man 2 fork)
	
	if(pid==0){
		printf("I'm the child (and a bad one!!)\n");
		int i=0;
		while(1)i=i+1;
	} else if(pid>0) {
		printf("I'm the parent, child has pid=%d\n", pid);	
		sleep(5);
		// Send a signal to the child process (man 2 kill, signal.h, man 7 signal)
		if(kill(pid, SIGKILL)==-1){
			perror("kill child process");
			exit(1);
		}
		// wait for the child to exit (man 2 wait)
		int child_status;
		if(wait(&child_status)==pid){
			// child_status now encodes information about the child
			printf("child status=%d exit status=%d\n",child_status, WEXITSTATUS(child_status));
			if(WIFEXITED(child_status)){
				printf("child exited successfully\n");
			}
		}
	} else {
		printf("Fork error, no child.\n");
		exit(1);
	}
	exit(0);
}


#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
int main() {
	long nprocs;
	nprocs = sysconf(_SC_NPROCESSORS_ONLN); // (man 3 sysconf)
	if (nprocs == -1)
		exit(EXIT_FAILURE);
	else if (nprocs == 0)
		nprocs = 1;
	printf ("%ld\n",nprocs);
	exit (EXIT_SUCCESS);
}

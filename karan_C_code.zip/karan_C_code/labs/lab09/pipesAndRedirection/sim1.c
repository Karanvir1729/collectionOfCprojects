#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	// I simulate the shell executing the command sort -n < infile > outfile
	int sortpid = fork();
	if (sortpid == 0) {
		/* I will exec sort -n, reading stdin from infile, writing stdout to outfile */

		int fdin, fdout;
		if ((fdin=open("infile",O_RDONLY)) < 0) {
			perror("infile");
			return(1);
		}
		if ((fdout=open("outfile", O_WRONLY|O_CREAT|O_TRUNC, 0666)) < 0) {
			perror("outfile");
			return(1);
		}

		dup2(fdin,0);
		dup2(fdout, 1);

		close(fdin); 
		close(fdout);

		execl("/usr/bin/sort", "sort", "-n", (char *)NULL);  
		perror("/usr/bin/sort");
		return(1);
	} else {
		/* parent */
		int status, pid;
		pid = wait(&status);
		printf("pid %d exit status %d\n", pid, status >> 8);
		return(0);
	}
}

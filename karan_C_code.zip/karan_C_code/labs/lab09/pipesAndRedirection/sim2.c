#include<unistd.h>
#include<stdlib.h>
#include<stdio.h> 
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

// Simulate sort -n | tail -3, with sort -n reading from stdin, tail -3 writing to stdout
int main(int argc, char ** argv){
	// I simulate the shell...build the pipeline backwards, so my child is tail -3
	int tailpid = fork();
        if (tailpid == 0) {
		// Build the pipeline backwards, so my child is sort -n
                /* I will exec tail -3, reading from my child (sort -n) on pipefd[0], writing to stdout */
		int pipefd[2];
		if(pipe(pipefd)==-1){
			perror("pipe call");
			exit(1);
		}
		int sortpid = fork();
		if(sortpid == 0){
			/* I will exec sort -n, reading from stdin, writing to my parent (tail -3) on pipefd[1] */
			dup2(pipefd[1], 1); // so my stdout goes to tail -n (my parent)
			close(pipefd[0]);
			close(pipefd[1]);
                	execl("/usr/bin/sort", "sort", "-n", (char *)NULL);
			perror("/usr/bin/sort");
			exit(1);
		} else { /* parent */
			dup2(pipefd[0], 0); // so my stdin comes from sort -n (my child)
			close(pipefd[0]);
			close(pipefd[1]);
                	execl("/usr/bin/tail", "tail", "-3", (char *)NULL);
			perror("/usr/bin/tail");
			exit(1);
		}
        } else {
                /* parent */
                int status, pid;
                pid = wait(&status);
                printf("pid %d exit status %d\n", pid, status >> 8);
                return(0);
        }
}

 // EXERCISE simulate sort -n < infile | tail -3 >  outfile 
// STEP 1: Draw the picture
// STEP 2: Code it

#include<unistd.h>
#include<stdlib.h>
#include<stdio.h> 
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char ** argv){
    int tailpid = fork();
    if (tailpid == 0) {
        printf("tailpid == 0");
        int pipefd[2];
        if (pipe(pipefd) == -1) {
            perror("pipe call");
            exit(1);
        }
        int sortpid = fork();
        if (sortpid == 0) {
            int fdin;
            
            if ((fdin=open("infile",O_RDONLY)) < 0) {
                perror("infile");
                return(1);
            }
            dup2(fdin,0);
            dup2(pipefd[1], 1);
            close(pipefd[1]);
            close(fdin);
            execl("/usr/bin/sort", "sort", "-n", (char *)NULL);
            perror("/usr/bin/sort");
            exit(1);
        }
        else {
            dup2(pipefd[0], 0);
            int fdout;

            if ((fdout=open("outfile", O_WRONLY|O_CREAT|O_TRUNC, 0666)) < 0) {
                perror("outfile");
                return(1);
            }
            dup2(fdout, 1);
            close(fdout);
            close(pipefd[1]);
            execl("/usr/bin/tail", "tail", "-3", (char *)NULL);
            perror("/usr/bin/tail");
            exit(1);
        }
    }
    else {
        int status, pid;
        pid = wait(&status);
        printf("pid %d exit status %d\n", pid, status >> 8);
        return(0);
    }   
}
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(int argc, char ** argv){
	// man 2 pipe
	int pipefd[2];
	if(pipe(pipefd)==-1){
		perror("pipe call");
		exit(1);
	}

	printf("pipefd[0]=%d pipefd[1]=%d\n",pipefd[0], pipefd[1]);

	// remember 0=stdin (reading), 1=stdout (writing)
	// similarly pipefd[0] is for reading, pipefd[1] is for writing

	#define MESSAGE_LEN 22
	char *mess1="This is the message 1";
	char *mess2="This is the message 2";
	char *mess3="This is the message 3";

	write(pipefd[1], mess1, MESSAGE_LEN); 
	write(pipefd[1], mess2, MESSAGE_LEN); 
	write(pipefd[1], mess3, MESSAGE_LEN); 

	#define BUFSIZE 10
	char buffer[BUFSIZE];
	ssize_t num_read=0;

	num_read=read(pipefd[0], buffer, MESSAGE_LEN);
	write(1,"read some bytes:", 17);
        write(1,buffer,num_read);
        write(1,"\n",1);

	num_read=read(pipefd[0], buffer, MESSAGE_LEN);
	write(1,"read some bytes:", 17);
        write(1,buffer,num_read);
        write(1,"\n",1);

	num_read=read(pipefd[0], buffer, MESSAGE_LEN);
	write(1,"read some bytes:", 17);
        write(1,buffer,num_read);
        write(1,"\n",1);

	// read blocks on an open pipe
	// num_read=read(pipefd[0], buffer, MESSAGE_LEN);

	exit(0);
}

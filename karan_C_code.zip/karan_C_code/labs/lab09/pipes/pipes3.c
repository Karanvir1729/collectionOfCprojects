#include<unistd.h>
#include<stdlib.h>
#include<stdio.h> // OK, I'm cheating, just to print out the sum!
#include<sys/types.h>
#include<sys/wait.h>


// child will generate integers, send them to the parent
// the parent will add them all up and print the result

int main(int argc, char ** argv){
	// man 2 pipe
	int pipefd[2];
	if(pipe(pipefd)==-1){
		perror("pipe call");
		exit(1);
	}

	// remember 0=stdin (reading), 1=stdout (writing)
	// similarly pipefd[0] is for reading, pipefd[1] is for writing
	// child writes to pipefd[1], parent reads from pipefd[0]
	// child closes pipefd[0], parent closes pipefd[1]

	// EXERCISE: Fix the code below...so that the parent child relationship is as described above

	pid_t pid;
	switch(pid=fork()){
		case -1:
			perror("fork");
			break;

		case 0: // child reads from pipefd[0], closes pipefd[1]
			close(pipefd[1]);
			{
				int sum=0, i=0;
				ssize_t num_read;
				while((num_read=read(pipefd[0], &i,sizeof(int)))>0){
					sum=sum+i;
				}
				printf("sum=%d\n",sum);
			}
			close(pipefd[0]);
			break;
		default: // parent writes on pipefd[1], closes pipefd[0]
			close(pipefd[0]);
			{
				int i;
				for(i=0;i<10;i++){
					write(pipefd[1], &i, sizeof(int));
				}
			}
			close(pipefd[1]); // so child knows we are done!
			wait(NULL); // wait for our children to finish
			break;
	}
	exit(0);
}
